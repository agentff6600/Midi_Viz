import { PORT_BOTTOM_TRIGGER, PORT_TOP_TRIGGER } from '../config/constants.js';
import Port from './Port.js';

/**
 * Vertical trigger line tied to a NodeBox.
 * u is normalized [0..1] across the node's graph width.
 */
class VTrigger {
  constructor(node, uNorm = 0.5) {
    this.node = node;
    this.u = Math.max(0, Math.min(1, uNorm));

    // Ports: bottom (out), top (in). Their X follows the trigger's X.
    this.portOut = new Port(node, PORT_BOTTOM_TRIGGER, 'out', () => {
      const x = this.getX();
      return { x, y: this.node.y + this.node.h + 12 };
    });
    this.portIn = new Port(node, PORT_TOP_TRIGGER, 'in', () => {
      const x = this.getX();
      return { x, y: this.node.y - 12 };
    });
  }

  // Current X position inside the node, aligned to graph rect
  getX() {
    const { gx, gw } = this.node.getGraphRect();
    return gx + this.u * gw;
  }

  // Drag handler: update u based on mouseX
  setUFromMouseX(mx) {
    const { gx, gw } = this.node.getGraphRect();
    const clampedX = Math.max(gx, Math.min(gx + gw, mx));
    this.u = gw > 0 ? (clampedX - gx) / gw : 0;
  }
}

export default VTrigger;
