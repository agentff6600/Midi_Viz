// MIDI Model: Enhanced Web MIDI access with comprehensive CC send/receive.
// Supports device enumeration, input monitoring, and output routing.

class MidiModel {
  constructor() {
    this.access = null;
    this.ready = false;
    this.initRequested = false;

    this.outputs = [];
    this.inputs = [];

    // Input selection: 'none' | 'all' | number[]
    this.inMode = 'all';

    // Output selection: 'all' | number[]
    this.outSelection = 'all';

    this.channel = 0; // 0..15
    this.lastGlobalVal = 0;

    // Enhanced input tracking (Priority 1.3)
    this.lastSeen = new Map(); // Track recent CC messages with timestamps
    this.onCCReceived = null; // Callback for CC input (for future recording system)

    this._onMIDIMessage = this._onMIDIMessage.bind(this);
  }

  async init() {
    if (this.initRequested) return;
    this.initRequested = true;
    try {
      if (!('requestMIDIAccess' in navigator)) {
        console.warn('Web MIDI not supported by this browser.');
        return;
      }
      this.access = await navigator.requestMIDIAccess({ sysex: false });
      this._refreshAll();
      this.access.onstatechange = () => this._refreshAll();
      this.ready = true;
    } catch (e) {
      console.warn('MIDI init failed:', e);
    }
  }

  _refreshAll() {
    this._refreshOutputs();
    this._refreshInputs();
    this._attachInputListener();
  }

  _refreshOutputs() {
    this.outputs = [];
    if (!this.access) return;
    for (const o of this.access.outputs.values()) this.outputs.push(o);

    if (this.outSelection !== 'all') {
      if (!Array.isArray(this.outSelection)) this.outSelection = [];
      this.outSelection = this.outSelection.filter(i => i >= 0 && i < this.outputs.length);
      if (this.outputs.length && this.outSelection.length === this.outputs.length) this.outSelection = 'all';
    }
  }

  _refreshInputs() {
    this.inputs = [];
    if (!this.access) return;
    for (const i of this.access.inputs.values()) this.inputs.push(i);

    if (this.inputs.length === 0) {
      this.inMode = 'none';
    } else if (Array.isArray(this.inMode)) {
      this.inMode = this.inMode.filter(i => i >= 0 && i < this.inputs.length);
      if (this.inMode.length === 0) this.inMode = 'none';
      if (this.inMode.length === this.inputs.length) this.inMode = 'all';
    } else if (this.inMode !== 'all' && this.inMode !== 'none') {
      this.inMode = 'all';
    }
  }

  _attachInputListener() {
    if (!this.access) return;
    for (const i of this.access.inputs.values()) i.onmidimessage = null;

    if (this.inMode === 'none') return;
    if (this.inMode === 'all') {
      for (const i of this.inputs) i.onmidimessage = this._onMIDIMessage;
    } else if (Array.isArray(this.inMode)) {
      for (const idx of this.inMode) {
        const inp = this.inputs[idx];
        if (inp) inp.onmidimessage = this._onMIDIMessage;
      }
    }
  }

  _onMIDIMessage(e) {
    const d = e.data;
    if (!d || d.length < 3) return;
    const st = d[0], type = st & 0xF0;
    const ch = (st & 0x0F) + 1; // MIDI channels 1-16

    const src = (e.currentTarget || e.target || null);
    const srcId = src && src.id ? src.id : (src && src.name ? 'name:' + src.name : 'unknown');
    const srcName = src && src.name || '';
    const srcManufacturer = src && src.manufacturer || '';

    if (type === 0xB0) { // CC message
      const cc = d[1] & 0x7F;
      const val = d[2] & 0x7F;
      
      // Update global value for oscilloscope and other uses
      this.lastGlobalVal = val;
      
      // Track this CC message with timestamp and source info
      const timestamp = performance.now();
      const key = `${ch}:${cc}`;
      this.lastSeen.set(key, { 
        ch, cc, val, 
        ts: timestamp, 
        srcId, srcName, srcManufacturer 
      });
      
      // Call callback if set (for future recording system)
      if (this.onCCReceived) {
        this.onCCReceived(ch, cc, val, timestamp, {
          id: srcId, 
          name: srcName, 
          manufacturer: srcManufacturer
        });
      }
      
      // Log for debugging (can be removed later)
      console.log(`MIDI CC: CH${ch} CC${cc} = ${val} from ${srcName || srcId}`);
    }
  }

  get out() {
    if (this.outSelection === 'all') return this.outputs[0] || null;
    if (Array.isArray(this.outSelection) && this.outSelection.length > 0) {
      return this.outputs[this.outSelection[0]] || null;
    }
    return null;
  }

  send(bytes) {
    if (this.outSelection === 'all') {
      if (!this.outputs || !this.outputs.length) return;
      for (const o of this.outputs) {
        try { o.send(bytes); } catch (e) { console.warn('MIDI send error (broadcast):', e); }
      }
      return;
    }
    if (Array.isArray(this.outSelection) && this.outSelection.length > 0) {
      for (const i of this.outSelection) {
        const o = this.outputs[i];
        if (!o) continue;
        try { o.send(bytes); } catch (e) { console.warn('MIDI send error:', e); }
      }
    }
  }

  sendCC(cc, val, ch = null) {
    const chan = (ch == null ? this.channel : ch) & 0x0F;
    this.send([0xB0 | chan, cc & 0x7F, val & 0x7F]);
    
    // Log outgoing MIDI for debugging
    if (this.ready && this.outputs.length > 0) {
      console.log(`MIDI OUT: CH${chan + 1} CC${cc} = ${val}`);
    }
  }

  // Utility methods for device management (Priority 1.3)
  getInputDeviceNames() {
    return this.inputs.map((inp, idx) => ({ 
      index: idx, 
      name: inp.name || `Input ${idx + 1}`,
      manufacturer: inp.manufacturer || '',
      id: inp.id || `input_${idx}`
    }));
  }

  getOutputDeviceNames() {
    return this.outputs.map((out, idx) => ({ 
      index: idx, 
      name: out.name || `Output ${idx + 1}`,
      manufacturer: out.manufacturer || '',
      id: out.id || `output_${idx}`
    }));
  }

  // Set input selection
  setInputMode(mode) {
    this.inMode = mode;
    this._attachInputListener();
  }

  // Set output selection
  setOutputSelection(selection) {
    this.outSelection = selection;
  }

  // Get readable device status for debugging
  getDeviceStatus() {
    return {
      ready: this.ready,
      inputCount: this.inputs.length,
      outputCount: this.outputs.length,
      currentChannel: this.channel + 1,
      inputMode: this.inMode,
      outputSelection: this.outSelection,
      lastGlobalVal: this.lastGlobalVal
    };
  }
}

export default MidiModel;
