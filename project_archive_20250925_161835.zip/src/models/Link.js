import { pointToSegmentDist } from '../utils/geometry.js';

/** Link between two ports (A -> B). Enhanced with bezier rendering and hover detection. */
class Link {
  constructor(portA, portB) {
    this.a = portA;
    this.b = portB;
    // Detect signal connections (for blue color)
    this.isSignal = (String(portA.role).startsWith('signal') && String(portB.role).startsWith('signal'));
  }

  // Bezier control points based on port outward directions
  curvePoints() {
    const A = this.a.getPos();
    const B = this.b.getPos();
    const outA = this.a.getOutward();
    const outB = this.b.getOutward();
    const d = Math.hypot(B.x - A.x, B.y - A.y);
    const h = Math.min(220, Math.max(40, d * 0.35));
    const c1 = { x: A.x + outA.x * h, y: A.y + outA.y * h };
    const c2 = { x: B.x + outB.x * h, y: B.y + outB.y * h };
    return { A, c1, c2, B };
  }

  // Get midpoint of bezier curve (for deletion icon)
  midpoint() {
    const { A, c1, c2, B } = this.curvePoints();
    const t = 0.5;
    // Bezier curve equation at t=0.5
    const x = Math.pow(1-t, 3) * A.x + 3 * Math.pow(1-t, 2) * t * c1.x + 
              3 * (1-t) * Math.pow(t, 2) * c2.x + Math.pow(t, 3) * B.x;
    const y = Math.pow(1-t, 3) * A.y + 3 * Math.pow(1-t, 2) * t * c1.y + 
              3 * (1-t) * Math.pow(t, 2) * c2.y + Math.pow(t, 3) * B.y;
    return { x, y };
  }

  // Distance from point to bezier curve (for hover detection)
  distanceTo(px, py, samples = 40) {
    const { A, c1, c2, B } = this.curvePoints();
    let prevX = A.x, prevY = A.y, minD = Infinity;
    
    for (let i = 1; i <= samples; i++) {
      const t = i / samples;
      // Bezier curve equation
      const x = Math.pow(1-t, 3) * A.x + 3 * Math.pow(1-t, 2) * t * c1.x + 
                3 * (1-t) * Math.pow(t, 2) * c2.x + Math.pow(t, 3) * B.x;
      const y = Math.pow(1-t, 3) * A.y + 3 * Math.pow(1-t, 2) * t * c1.y + 
                3 * (1-t) * Math.pow(t, 2) * c2.y + Math.pow(t, 3) * B.y;
      
      const d = pointToSegmentDist(px, py, prevX, prevY, x, y);
      if (d < minD) minD = d;
      prevX = x;
      prevY = y;
    }
    return minD;
  }
}

export default Link;
