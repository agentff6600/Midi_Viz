import { PORT_LEFT, PORT_RIGHT, PORT_BOTTOM_TRIGGER, PORT_TOP_TRIGGER, PORT_RIGHT_TRIGGER, PORT_R } from '../config/constants.js';
import { dist2 } from '../utils/geometry.js';

// Port model that supports both regular node ports and trigger ports.
class Port {
  constructor(node, kind, role, positionFn = null) {
    this.node = node;           // NodeBox instance
    this.kind = kind;           // PORT_LEFT | PORT_RIGHT | PORT_BOTTOM_TRIGGER | PORT_TOP_TRIGGER
    this.role = role;           // 'in' | 'out'
    this.positionFn = positionFn; // Optional function that returns {x, y} for dynamic positioning
  }

  // Center position of this port
  getPos() {
    // If we have a custom position function (used by triggers), use it
    if (this.positionFn) {
      return this.positionFn();
    }

    // Default positioning for regular node ports
    const n = this.node;
    if (this.kind === PORT_LEFT) {
      return { x: n.x, y: n.y + n.h / 2 };
    }
    if (this.kind === PORT_RIGHT) {
      return { x: n.x + n.w, y: n.y + n.h / 2 };
    }
    
    // VTrigger ports use triggerX
    if (this.kind === PORT_BOTTOM_TRIGGER) {
      return { x: this.triggerX, y: n.y + n.h + 20 };
    }
    if (this.kind === PORT_TOP_TRIGGER) {
      return { x: this.triggerX, y: n.y - 20 };
    }
    
    // HTrigger ports calculate position dynamically
    if (this.kind === PORT_RIGHT_TRIGGER) {
      // Find the HTrigger this port belongs to and calculate Y position dynamically
      let triggerY = n.y + n.h / 2; // fallback
      
      for (const ht of n.hTriggers || []) {
        if (ht.portUp === this) {
          triggerY = ht.getY() - 10; // Above the trigger line
          break;
        }
        if (ht.portDown === this) {
          triggerY = ht.getY() + 10; // Below the trigger line  
          break;
        }
      }
      
      return { x: n.x + n.w + 20, y: triggerY };
    }
    
    return { x: n.x, y: n.y };
  }

  // For bezier curvature, return outward unit vector from the node center toward the port
  getOutward() {
    const n = this.node;
    const c = { x: n.x + n.w / 2, y: n.y + n.h / 2 };
    const p = this.getPos();
    const dx = p.x - c.x, dy = p.y - c.y;
    const len = Math.hypot(dx, dy) || 1;
    return { x: dx / len, y: dy / len };
  }

  hits(mx, my) {
    const p = this.getPos();
    return dist2(mx, my, p.x, p.y) <= (PORT_R * PORT_R);
  }
}

export default Port;
