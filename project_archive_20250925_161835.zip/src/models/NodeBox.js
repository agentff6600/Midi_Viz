import { BOX_W, BOX_H, DEFAULT_PLAYBACK_DURATION_MS } from '../config/constants.js';
import Port from './Port.js';
import VTrigger from './VTrigger.js';
import HTrigger from './HTrigger.js';
import { PORT_LEFT, PORT_RIGHT } from '../config/constants.js';

class NodeBox {
  constructor(x, y, label = 'CC 1', samples = null, widthOverride = null, durationOverride = null) {
    this.x = x;
    this.y = y;
    this.w = widthOverride ?? BOX_W;
    this.h = BOX_H;

    this.label = label;
    this.cc = NodeBox.parseCC(label);

    // Samples are expected in 0..1 range.
    this.samples = samples || NodeBox.makeSine(200);
    
    // Duration-based timing system (recording-aware)
    this.durationMs = durationOverride ?? DEFAULT_PLAYBACK_DURATION_MS;

    // Playback state
    this.playing = false;
    this.playStart = 0;
    this._lastCCSent = -1;
    this._prevT = 0;
    this.hasFiredEnd = false;
    this._startU = 0; // Track where playback started from

    // Ports
    this.left = new Port(this, PORT_LEFT, 'in');
    this.right = new Port(this, PORT_RIGHT, 'out');

    // VTriggers - can be created by clicking top edge
    this.vTriggers = [];
    this._vFiredThisRun = new Set(); // Track which triggers have fired during current playback
    
    // HTriggers - can be created by clicking right edge
    this.hTriggers = [];
  }

  static parseCC(label) {
    const m = String(label || '').match(/CC\s*(\d+)/i);
    const n = m ? parseInt(m[1], 10) : 1;
    return Math.max(0, Math.min(127, isNaN(n) ? 1 : n));
  }

  // Example waveforms
  static makeSine(n) {
    const a = [];
    for (let i = 0; i < n; i++) a.push((Math.sin((i / (n - 1)) * Math.PI * 2) + 1) / 2);
    return a;
  }
  static makeSaw(n) {
    const a = [];
    for (let i = 0; i < n; i++) a.push(i / (n - 1));
    return a;
  }
  static makeRandomSmooth(n) {
    const a = [];
    let v = Math.random();
    for (let i = 0; i < n; i++) {
      v += (Math.random() - 0.5) * 0.2;
      v = Math.max(0, Math.min(1, v));
      a.push(v);
    }
    // light smoothing
    for (let k = 0; k < 2; k++) for (let i = 1; i < n - 1; i++) a[i] = (a[i - 1] + a[i] + a[i + 1]) / 3;
    return a;
  }

  bodyHits(mx, my) {
    return mx >= this.x && mx <= this.x + this.w && my >= this.y && my <= this.y + this.h;
  }

  getGraphRect() {
    // Minimal margins to avoid overlap issues while keeping it mostly seamless  
    return { gx: this.x + 2, gy: this.y + 2, gw: this.w - 4, gh: this.h - 4 };
  }

  startPlayback() {
    this.playing = true;
    this.playStart = millis();
    this._lastCCSent = -1;
    this._prevT = 0;
    this.hasFiredEnd = false;
    this._startU = 0;
    this._vFiredThisRun.clear();
    
    // Reset HTrigger crossing state
    for (const ht of this.hTriggers) {
      ht.resetCrossingState();
    }
  }

  // Start playback from a specific U position (for trigger input)
  startPlaybackFromU(u) {
    const clampedU = Math.max(0, Math.min(1, u));
    this.playing = true;
    this.playStart = millis();
    this._lastCCSent = -1;
    this._prevT = clampedU; // Start from this normalized position
    this.hasFiredEnd = false;
    this._startU = clampedU; // Remember where we started from
    this._vFiredThisRun.clear();
    
    // Mark any triggers before this U position as already fired
    for (let i = 0; i < this.vTriggers.length; i++) {
      if (this.vTriggers[i].u <= clampedU) {
        this._vFiredThisRun.add(i);
      }
    }
    
    // Reset HTrigger crossing state
    for (const ht of this.hTriggers) {
      ht.resetCrossingState();
    }
  }

  // Create a new vertical trigger at mouse position
  addVTriggerAtMouse(mx) {
    const { gx, gw } = this.getGraphRect();
    const clampedX = Math.max(gx, Math.min(gx + gw, mx));
    const u = gw > 0 ? (clampedX - gx) / gw : 0.5;
    const vt = new VTrigger(this, u);
    this.vTriggers.push(vt);
    return vt;
  }

  // Create a new horizontal trigger at mouse position
  addHTriggerAtMouse(my) {
    const { gy, gh } = this.getGraphRect();
    const clampedY = Math.max(gy, Math.min(gy + gh, my));
    const v = gh > 0 ? 1 - (clampedY - gy) / gh : 0.5; // Invert Y to voltage
    const ht = new HTrigger(this, v);
    this.hTriggers.push(ht);
    ht.updatePortPositions(); // Set initial port positions
    return ht;
  }

  // Check if point is in the top create area for VTriggers
  getTopCreateRect() {
    // With seamless graph, provide a small top strip for trigger creation
    return { x: this.x, y: this.y, w: this.w, h: 15 }; // 15px top strip
  }

  // Check if point is in the right create area for HTriggers  
  getRightCreateRect() {
    // With seamless graph, provide a small right strip for trigger creation
    return { x: this.x + this.w - 15, y: this.y, w: 15, h: this.h }; // 15px right strip
  }

  // Get all ports including trigger ports
  getAllPorts() {
    const ports = [this.left, this.right];
    for (const vt of this.vTriggers) {
      ports.push(vt.portOut, vt.portIn);
    }
    for (const ht of this.hTriggers) {
      ports.push(ht.portUp, ht.portDown);
    }
    return ports;
  }

  valueAt(tNorm) {
    const n = this.samples.length;
    const pos = Math.max(0, Math.min(1, tNorm)) * (n - 1);
    const i = Math.floor(pos), f = pos - i;
    const a = this.samples[i], b = this.samples[Math.min(i + 1, n - 1)];
    return a + (b - a) * f;
  }

  updateAndMaybeSend(midi) {
    const { gx, gw } = this.getGraphRect();
    let endedNow = false;

    let tNow = 0;
    
    // If group controlled, don't do individual timing or MIDI sending
    if (this._groupControlled) {
      // Group playback controls timing and MIDI - just update triggers
      tNow = this._prevT || 0;
      
      // Check VTrigger firing using the same gx, gw from above
      const currentX = gx + gw * tNow;
      
      for (let i = 0; i < this.vTriggers.length; i++) {
        const vt = this.vTriggers[i];
        const triggerX = vt.getX();
        
        // If playhead has crossed this trigger and we haven't fired it yet this run
        if (!this._vFiredThisRun.has(i) && currentX >= triggerX) {
          this._vFiredThisRun.add(i);
          // Fire trigger - will be handled by AppController's trigger propagation
          if (this.onTriggerFired) {
            this.onTriggerFired(vt.portOut, vt.u);
          }
        }
      }

      // Check HTrigger intersections
      const vNow = this.valueAt(tNow);
      for (const ht of this.hTriggers) {
        ht.checkIntersection(tNow, vNow, this.onTriggerFired);
      }
      
      return endedNow; // No individual timing when group controlled
    }
    
    if (this.playing) {
      const elapsed = millis() - this.playStart;
      // Duration-based timing: use node's durationMs property (recording-aware)
      const remainingDistance = 1 - this._startU;
      const adjustedDurationMs = this.durationMs * remainingDistance;
      const progress = elapsed / adjustedDurationMs;
      // Calculate actual position: start position + progress through remaining distance
      tNow = Math.max(0, Math.min(1, this._startU + progress * remainingDistance));
      
      if (tNow >= 1) {
        this.playing = false;
        if (!this.hasFiredEnd) {
          this.hasFiredEnd = true;
          endedNow = true;
          // Fire right port when playback ends
          if (this.onTriggerFired) {
            this.onTriggerFired(this.right, 1.0);
          }
        }
      }
    } else {
      // idle head pinned at last value
      tNow = this._prevT || 0;
    }

    const vNow = this.valueAt(tNow);
    const ccVal = Math.max(0, Math.min(127, Math.round(vNow * 127)));
    if (ccVal !== this._lastCCSent && midi && midi.ready && midi.out) {
      midi.sendCC(this.cc, ccVal);
      this._lastCCSent = ccVal;
    }

    // Check VTrigger firing using the same gx, gw from above
    const currentX = gx + gw * tNow;
    
    for (let i = 0; i < this.vTriggers.length; i++) {
      const vt = this.vTriggers[i];
      const triggerX = vt.getX();
      
      // If playhead has crossed this trigger and we haven't fired it yet this run
      if (!this._vFiredThisRun.has(i) && currentX >= triggerX) {
        this._vFiredThisRun.add(i);
        // Fire trigger - will be handled by AppController's trigger propagation
        if (this.onTriggerFired) {
          this.onTriggerFired(vt.portOut, vt.u);
        }
      }
    }

    // Check HTrigger intersections
    for (const ht of this.hTriggers) {
      ht.checkIntersection(tNow, vNow, this.onTriggerFired);
    }

    this._prevT = tNow;
    return endedNow;
  }
}

export default NodeBox;
