import Port from './Port.js';
import { PORT_LEFT_TRIGGER, PORT_RIGHT_TRIGGER } from '../config/constants.js';

/**
 * HTrigger: Horizontal trigger that fires when waveform value crosses a voltage level.
 * Unlike VTrigger (time-based), HTrigger is value-based.
 */
class HTrigger {
  constructor(node, v) {
    this.node = node;
    this.v = Math.max(0, Math.min(1, v)); // Level 0.0-1.0
    
    // Both ports use RIGHT_TRIGGER and are positioned on the right side
    this.portUp = new Port(node, PORT_RIGHT_TRIGGER, 'out');
    this.portDown = new Port(node, PORT_RIGHT_TRIGGER, 'out');
    
    // Set initial port positions
    this.updatePortPositions();
    
    // Track crossing state
    this.lastValue = null;
    this.lastT = null;
    this.hasFiredUp = false;
    this.hasFiredDown = false;
  }
  
  // Get Y coordinate of the trigger line
  getY() {
    const { gy, gh } = this.node.getGraphRect();
    return gy + gh * (1 - this.v); // Invert because higher voltage = lower Y
  }
  
  // Set voltage level from mouse Y coordinate
  setVFromMouseY(mouseY) {
    const { gy, gh } = this.node.getGraphRect();
    const clampedY = Math.max(gy, Math.min(gy + gh, mouseY));
    this.v = Math.max(0, Math.min(1, 1 - (clampedY - gy) / gh)); // Invert Y to voltage
    this.updatePortPositions();
  }
  
  // Update port positions based on current trigger line position  
  updatePortPositions() {
    const triggerY = this.getY();
    
    // Set triggerY property on ports (matches original implementation)
    this.portUp.triggerY = triggerY - 10;   // Above the trigger line
    this.portDown.triggerY = triggerY + 10; // Below the trigger line
  }
  
  // Ensure ports are positioned correctly (call this before accessing port positions)
  ensurePortPositions() {
    this.updatePortPositions();
  }
  
  // Check for intersection crossing and fire triggers if needed
  checkIntersection(currentT, currentValue, onTriggerFired) {
    if (this.lastValue === null || this.lastT === null) {
      this.lastValue = currentValue;
      this.lastT = currentT;
      return;
    }
    
    const prevValue = this.lastValue;
    const prevT = this.lastT;
    const currValue = currentValue;
    const currT = currentT;
    
    // Check if playhead crossed the HTrigger line
    // Up-crossing: waveform goes from below to above HTrigger line
    if (prevValue < this.v && currValue >= this.v && !this.hasFiredUp) {
      this.hasFiredUp = true;
      this.hasFiredDown = false; // Reset opposite direction
      if (onTriggerFired) {
        onTriggerFired(this.portUp, this.v);
      }
    }
    // Down-crossing: waveform goes from above to below HTrigger line  
    else if (prevValue > this.v && currValue <= this.v && !this.hasFiredDown) {
      this.hasFiredDown = true;
      this.hasFiredUp = false; // Reset opposite direction
      if (onTriggerFired) {
        onTriggerFired(this.portDown, this.v);
      }
    }
    
    this.lastValue = currValue;
    this.lastT = currT;
  }
  
  // Get X coordinate where trigger line stops (before connectors)
  get stopX() {
    const portX = this.node.x + this.node.w + 20;
    return portX - 20;
  }

  // Compute crossing points where waveform intersects this trigger level
  computeCrossings(dir = "up") {
    const dots = [];
    const { gx, gy, gw, gh } = this.node.getGraphRect();
    const levelVal = this.v; // Use v directly (0-1 range)
    const n = this.node.samples.length;
    
    for (let i = 0; i < n - 1; i++) {
      const v0 = this.node.samples[i];
      const v1 = this.node.samples[i + 1];
      
      if (dir === "up" && v0 < levelVal && v1 >= levelVal && v1 !== v0) {
        const t = (levelVal - v0) / (v1 - v0);
        const x0 = gx + (i / (n - 1)) * gw;
        const x1 = gx + ((i + 1) / (n - 1)) * gw;
        dots.push({
          x: x0 + (x1 - x0) * Math.max(0, Math.min(1, t)),
          y: this.getY()
        });
      }
      
      if (dir === "down" && v0 > levelVal && v1 <= levelVal && v1 !== v0) {
        const t = (levelVal - v0) / (v1 - v0);
        const x0 = gx + (i / (n - 1)) * gw;
        const x1 = gx + ((i + 1) / (n - 1)) * gw;
        dots.push({
          x: x0 + (x1 - x0) * Math.max(0, Math.min(1, t)),
          y: this.getY()
        });
      }
    }
    
    return dots;
  }

  // Reset crossing state (call when starting new playback)
  resetCrossingState() {
    this.lastValue = null;
    this.lastT = null;
    this.hasFiredUp = false;
    this.hasFiredDown = false;
  }
}

export default HTrigger;
