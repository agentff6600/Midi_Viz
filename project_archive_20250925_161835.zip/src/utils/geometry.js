// Geometry and math helpers (no DOM dependencies)

export function dist2(ax, ay, bx, by) {
  const dx = ax - bx, dy = ay - by;
  return dx * dx + dy * dy;
}

export function pointInRect(px, py, x, y, w, h) {
  return px >= x && px <= x + w && py >= y && py <= y + h;
}

export function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

// Distance from point P to segment AB
export function pointToSegmentDist(px, py, ax, ay, bx, by) {
  const vx = bx - ax, vy = by - ay;
  const wx = px - ax, wy = py - ay;
  const c1 = vx * wx + vy * wy;
  if (c1 <= 0) return Math.hypot(px - ax, py - ay);
  const c2 = vx * vx + vy * vy;
  if (c2 <= c1) return Math.hypot(px - bx, py - by);
  const t = c1 / c2;
  const qx = ax + t * vx, qy = ay + t * vy;
  return Math.hypot(px - qx, py - qy);
}

// Distance from point to rectangle (0 if inside)
export function pointRectDistance(px, py, rx, ry, rw, rh) {
  const dx = (px < rx) ? (rx - px) : (px > rx + rw ? px - (rx + rw) : 0);
  const dy = (py < ry) ? (ry - py) : (py > ry + rh ? py - (ry + rh) : 0);
  return Math.hypot(dx, dy);
}

// Distance between two rectangles (0 if overlapping)
export function rectsMinDistance(ax, ay, aw, ah, bx, by, bw, bh) {
  const ax2 = ax + aw, ay2 = ay + ah;
  const bx2 = bx + bw, by2 = by + bh;
  const dx = (ax > bx2) ? (ax - bx2) : (bx > ax2 ? (bx - ax2) : 0);
  const dy = (ay > by2) ? (ay - by2) : (by > ay2 ? (by - ay2) : 0);
  return Math.hypot(dx, dy);
}

// Snap position to nearby alignment guides
export function computeDockSnap(leadNode, proposedX, proposedY, otherNodes, snapPx = 8, nearPx = 20) {
  let snapX = proposedX, snapY = proposedY;
  let bestDx = null, bestDy = null;
  let snappedTo = null;
  let guideV = null, guideH = null;

  const leadRect = { x: proposedX, y: proposedY, w: leadNode.w, h: leadNode.h };
  const L = { 
    left: proposedX, 
    cx: proposedX + leadNode.w/2, 
    right: proposedX + leadNode.w 
  };
  const T = { 
    top: proposedY, 
    cy: proposedY + leadNode.h/2, 
    bottom: proposedY + leadNode.h 
  };

  for (const m of otherNodes) {
    if (m === leadNode) continue;
    
    const minDist = rectsMinDistance(leadRect.x, leadRect.y, leadRect.w, leadRect.h, m.x, m.y, m.w, m.h);
    if (minDist > nearPx) continue;

    const Mx = { left: m.x, cx: m.x + m.w/2, right: m.x + m.w };
    const My = { top: m.y, cy: m.y + m.h/2, bottom: m.y + m.h };

    // Check X alignment
    for (const [xLKey, xL] of Object.entries(L)) {
      for (const [xMKey, xM] of Object.entries(Mx)) {
        const dx = xM - xL;
        if (Math.abs(dx) <= snapPx && (bestDx === null || Math.abs(dx) < Math.abs(bestDx))) {
          bestDx = dx;
          snapX = proposedX + dx;
          guideV = xM;
          snappedTo = m;
        }
      }
    }

    // Check Y alignment
    for (const [yTKey, yT] of Object.entries(T)) {
      for (const [yMKey, yM] of Object.entries(My)) {
        const dy = yM - yT;
        if (Math.abs(dy) <= snapPx && (bestDy === null || Math.abs(dy) < Math.abs(bestDy))) {
          bestDy = dy;
          snapY = proposedY + dy;
          guideH = yM;
          snappedTo = m;
        }
      }
    }

    // Check stacking gaps (vertical)
    const underY = m.y + m.h + 12; // NB_STACK_GAP
    const dy = underY - proposedY;
    if (Math.abs(dy) <= snapPx && (bestDy === null || Math.abs(dy) < Math.abs(bestDy))) {
      bestDy = dy;
      snapY = proposedY + dy;
      guideH = m.y + m.h;
      snappedTo = m;
    }

    const aboveY = m.y - (leadNode.h + 12); // NB_STACK_GAP
    const dyAbove = aboveY - proposedY;
    if (Math.abs(dyAbove) <= snapPx && (bestDy === null || Math.abs(dyAbove) < Math.abs(bestDy))) {
      bestDy = dyAbove;
      snapY = proposedY + dyAbove;
      guideH = m.y;
      snappedTo = m;
    }
  }

  return { 
    x: snapX, 
    y: snapY, 
    guideV, 
    guideH, 
    snappedTo 
  };
}
