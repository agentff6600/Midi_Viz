import { DEV } from '../config/dev.js';

// Logging levels in order of severity
const LOG_LEVELS = {
  debug: 0,
  info: 1, 
  warn: 2,
  error: 3,
  none: 4
};

class Logger {
  constructor() {
    this.level = LOG_LEVELS[DEV.LOG_LEVEL] || LOG_LEVELS.debug;
    this.enabled = DEV.DEBUG;
    
    // Allow runtime override via window.__DEV
    if (typeof window !== 'undefined' && window.__DEV) {
      this.enabled = window.__DEV.DEBUG ?? this.enabled;
      this.level = LOG_LEVELS[window.__DEV.LOG_LEVEL] || this.level;
    }
  }

  debug(tag, ...args) {
    if (this.enabled && this.level <= LOG_LEVELS.debug) {
      console.log(`[DEBUG:${tag}]`, ...args);
    }
  }

  info(tag, ...args) {
    if (this.enabled && this.level <= LOG_LEVELS.info) {
      console.info(`[INFO:${tag}]`, ...args);
    }
  }

  warn(tag, ...args) {
    if (this.enabled && this.level <= LOG_LEVELS.warn) {
      console.warn(`[WARN:${tag}]`, ...args);
    }
  }

  error(tag, ...args) {
    if (this.enabled && this.level <= LOG_LEVELS.error) {
      console.error(`[ERROR:${tag}]`, ...args);
    }
  }

  // Utility for rate-limited logging (e.g., MIDI input)
  throttle(fn, delay = 1000) {
    let lastCall = 0;
    return (...args) => {
      const now = Date.now();
      if (now - lastCall >= delay) {
        lastCall = now;
        fn(...args);
      }
    };
  }
}

// Export singleton instance
export const log = new Logger();

// For special cases where a fresh instance is needed
export { Logger };
