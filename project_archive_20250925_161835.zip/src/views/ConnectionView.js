import { DELETE_ICON_R } from '../config/constants.js';

/**
 * ConnectionView: draws cable links and drag-preview on the p5 canvas.
 * Enhanced with hover detection, deletion icons, and signal cable coloring.
 */
class ConnectionView {
  draw(link, isHovered = false) {
    const { A, c1, c2, B } = link.curvePoints();
    
    // Color coding: blue for signal cables, white for normal
    if (link.isSignal) {
      stroke(80, 160, 255); // Blue for signal connections
    } else {
      stroke(255); // White for normal connections
    }
    
    strokeWeight(1);
    noFill();
    bezier(A.x, A.y, c1.x, c1.y, c2.x, c2.y, B.x, B.y);

    // Draw delete icon if hovered
    if (isHovered) {
      const mid = link.midpoint();
      this.drawDeleteIcon(mid.x, mid.y);
    }
  }

  drawPreview(fromPort, toPoint, targetPort = null) {
    const A = fromPort.getPos();
    const outA = fromPort.getOutward();
    const B = { x: toPoint.x, y: toPoint.y };
    const d = Math.hypot(B.x - A.x, B.y - A.y);
    const h = Math.min(220, Math.max(40, d * 0.35));

    const c1 = { x: A.x + outA.x * h, y: A.y + outA.y * h };
    
    let c2;
    if (targetPort) {
      // Use target port's outward direction
      const outB = targetPort.getOutward();
      c2 = { x: B.x + outB.x * h, y: B.y + outB.y * h };
    } else {
      // Mirror the outward vector from A for preview
      const mirror = { x: -outA.x, y: -outA.y };
      c2 = { x: B.x + mirror.x * h, y: B.y + mirror.y * h };
    }

    // Color preview based on connection type
    const isSignalPreview = targetPort && 
      String(fromPort.role).startsWith('signal') && 
      String(targetPort.role).startsWith('signal');
    
    if (isSignalPreview) {
      stroke(80, 160, 255); // Blue preview for signal
    } else {
      stroke(255, 160, 80); // Orange preview for normal
    }
    
    strokeWeight(1);
    noFill();
    bezier(A.x, A.y, c1.x, c1.y, c2.x, c2.y, B.x, B.y);
  }

  // Draw delete icon (red X)
  drawDeleteIcon(x, y) {
    stroke(255);
    strokeWeight(1.5);
    fill(0);
    circle(x, y, DELETE_ICON_R * 1.5);
    
    const arm = DELETE_ICON_R * 0.2;
    stroke(255);
    line(x - arm, y - arm, x + arm, y + arm);
    line(x - arm, y + arm, x + arm, y - arm);
  }
}

export default ConnectionView;
