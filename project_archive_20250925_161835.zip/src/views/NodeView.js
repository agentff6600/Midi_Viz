import { BOX_H, PORT_R } from '../config/constants.js';

/**
 * NodeView: draws a NodeBox model on the p5 canvas.
 * Relies on p5 global functions (p5 loaded via script tag).
 */
class NodeView {
  constructor() {}

  draw(node, controller = null) {
    // Frame
    stroke(255);
    strokeWeight(1.5);
    noFill();
    rect(node.x, node.y, node.w, node.h);

    // Title - adjusted position for seamless graph
    noStroke();
    fill(255);
    textAlign(LEFT, TOP);
    textSize(11);
    const header = node.label || 'CC';
    text(header, node.x + 4, node.y + 2);

    // Graph
    const { gx, gy, gw, gh } = node.getGraphRect();
    stroke(255);
    strokeWeight(1);
    noFill();
    beginShape();
    const N = node.samples.length;
    for (let i = 0; i < N; i++) {
      const sx = map(i, 0, N - 1, gx, gx + gw);
      const sy = map(node.samples[i], 0, 1, gy + gh, gy);
      vertex(sx, sy);
    }
    endShape();

    // Playhead (red) when playing - but not when group controlled
    if (node.playing && !node._groupControlled) {
      // Approximate from node._prevT which is updated by model
      const t = node._prevT || 0;
      const cx = gx + gw * t;
      stroke(255, 0, 0);
      strokeWeight(2);
      line(cx, gy, cx, gy + gh);
    }

    // VTriggers
    this.drawVTriggers(node);

    // HTriggers
    this.drawHTriggers(node);

    // Create area for VTriggers (top edge)
    this.drawVTriggerCreateArea(node);

    // Create area for HTriggers (right edge)
    this.drawHTriggerCreateArea(node);

    // Ports (regular node ports) - only show if visible
    this.drawPortCircle(node.left, controller);
    this.drawPortCircle(node.right, controller);

    // Trigger ports (always visible - no controller passed)
    for (const vt of node.vTriggers) {
      this.drawPortCircle(vt.portOut);
      this.drawPortCircle(vt.portIn);
    }
    for (const ht of node.hTriggers) {
      this.drawPortCircle(ht.portUp);
      this.drawPortCircle(ht.portDown);
    }
  }

  drawPortCircle(port, controller) {
    if (!port) return;
    // Only draw if port should be visible (Priority 1.1)
    if (controller && !controller.shouldShowPort(port)) return;
    
    const p = port.getPos();
    stroke(255);
    strokeWeight(2);
    fill(0);
    circle(p.x, p.y, PORT_R * 2);
  }

  drawVTriggers(node) {
    for (const vt of node.vTriggers) {
      const x = vt.getX();
      
      // Vertical line from top of node to bottom
      stroke(255);
      strokeWeight(1);
      line(x, node.y, x, node.y + node.h);
      
      // Extend to ports
      const topY = vt.portIn.getPos().y;
      const bottomY = vt.portOut.getPos().y;
      line(x, topY, x, node.y);
      line(x, node.y + node.h, x, bottomY);

      // Red dot at graph intersection (trigger position value)
      const { gy, gh } = node.getGraphRect();
      const triggerVal = node.valueAt(vt.u);
      const dotY = map(triggerVal, 0, 1, gy + gh, gy);
      noStroke();
      fill(255, 0, 0);
      circle(x, dotY, 6);
    }
  }

  drawHTriggers(node) {
    for (const ht of node.hTriggers) {
      // Ensure port positions are updated (fixes dragging issue)
      ht.ensurePortPositions();
      
      const y = ht.getY();
      
      // Horizontal line from left of node to stopX
      stroke(255);
      strokeWeight(1);
      line(node.x, y, ht.stopX, y);
      
      // Bezier connectors to ports (like original)
      const sx = ht.stopX;
      const sy = y;
      const upPort = ht.portUp.getPos();
      const downPort = ht.portDown.getPos();
      
      // Calculate bezier control points
      const dx = Math.max(1, Math.min(upPort.x, downPort.x) - sx);
      const r = Math.min(24, dx * 0.35);
      
      noFill();
      stroke(255);
      strokeWeight(1);
      
      const c1x = sx + r;
      const c1y = sy;
      
      // Bezier curves to ports
      bezier(sx, sy, c1x, c1y, upPort.x - r, upPort.y, upPort.x, upPort.y);
      bezier(sx, sy, c1x, c1y, downPort.x - r, downPort.y, downPort.x, downPort.y);

      // Red dots at crossing points (not playhead position)
      const upCrossings = ht.computeCrossings('up');
      const downCrossings = ht.computeCrossings('down');
      
      noStroke();
      fill(255, 0, 0);
      for (const dot of upCrossings) {
        circle(dot.x, dot.y, 6);
      }
      for (const dot of downCrossings) {
        circle(dot.x, dot.y, 6);
      }
    }
  }

  drawVTriggerCreateArea(node) {
    const createRect = node.getTopCreateRect();
    if (createRect.h <= 0) return;

    // Check if mouse is over the create area
    const overCreate = (mouseX >= createRect.x && mouseX <= createRect.x + createRect.w && 
                       mouseY >= createRect.y && mouseY <= createRect.y + createRect.h);
    
    if (overCreate) {
      // Highlight the create area
      noStroke();
      fill(255, 100);
      rect(createRect.x, createRect.y, createRect.w, createRect.h);

      // Show preview line where trigger would be created
      const { gx, gw } = node.getGraphRect();
      const previewX = Math.max(gx, Math.min(gx + gw, mouseX));
      stroke(255);
      strokeWeight(1.5);
      line(previewX, node.y, previewX, node.y + node.h);
    }
  }

  drawHTriggerCreateArea(node) {
    const createRect = node.getRightCreateRect();
    if (createRect.w <= 0) return;

    // Check if mouse is over the create area
    const overCreate = (mouseX >= createRect.x && mouseX <= createRect.x + createRect.w && 
                       mouseY >= createRect.y && mouseY <= createRect.y + createRect.h);
    
    if (overCreate) {
      // Highlight the create area
      noStroke();
      fill(255, 100);
      rect(createRect.x, createRect.y, createRect.w, createRect.h);

      // Show preview line where trigger would be created
      const { gy, gh } = node.getGraphRect();
      const previewY = Math.max(gy, Math.min(gy + gh, mouseY));
      stroke(255);
      strokeWeight(1.5);
      line(node.x, previewY, node.x + node.w, previewY);
    }
  }
}

export default NodeView;
