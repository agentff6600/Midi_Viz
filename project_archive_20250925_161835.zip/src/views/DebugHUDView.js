class DebugHUDView {
  constructor() {
    this.x = 20;
    this.y = 20;
    this.bgAlpha = 120;
    this.textSize = 11;
    this.lineHeight = 14;
  }

  draw(p5, controller) {
    if (!controller) return;

    const info = this.gatherDebugInfo(controller);
    const lines = this.formatLines(info);
    
    // Calculate HUD dimensions
    const maxWidth = Math.max(...lines.map(line => line.length * 6.5)); // Rough char width
    const hudWidth = Math.max(180, maxWidth);
    const hudHeight = lines.length * this.lineHeight + 16;

    // Semi-transparent background
    p5.noStroke();
    p5.fill(0, 0, 0, this.bgAlpha);
    p5.rect(this.x, this.y, hudWidth, hudHeight, 4);

    // Header
    p5.fill(100, 255, 100);
    p5.textAlign(p5.LEFT, p5.TOP);
    p5.textSize(this.textSize + 1);
    p5.text('DEBUG HUD (D to toggle)', this.x + 8, this.y + 4);

    // Debug lines
    p5.fill(255);
    p5.textSize(this.textSize);
    
    lines.forEach((line, i) => {
      const yPos = this.y + 22 + (i * this.lineHeight);
      
      // Color coding for different types
      if (line.includes('ACTIVE') || line.includes('TRUE')) {
        p5.fill(100, 255, 100); // Green for active states
      } else if (line.includes('PENDING') || line.includes('DRAGGING')) {
        p5.fill(255, 200, 100); // Orange for pending/dragging
      } else if (line.includes('ERROR') || line.includes('FAILED')) {
        p5.fill(255, 100, 100); // Red for errors
      } else {
        p5.fill(200, 200, 200); // Gray for normal info
      }
      
      p5.text(line, this.x + 8, yPos);
    });
  }

  gatherDebugInfo(controller) {
    return {
      // Dragging states
      draggingNode: controller._draggingNode?.active || false,
      draggingNodeName: controller._draggingNode?.node?.label || null,
      draggingCable: controller._draggingCable?.active || false,
      draggingTrigger: controller._draggingTrigger?.active || false,
      draggingTriggerType: controller._draggingTrigger?.triggerType || null,

      // Deletion states
      deletionPending: controller._deletionPending || false,
      boxDeletionNode: controller._boxDeletion?.node?.label || null,
      triggerDeletionPending: controller._triggerDeletionPending || false,
      triggerDeletionNode: controller._triggerDeletion?.node?.label || null,
      triggerDeletionType: controller._triggerDeletion?.triggerType || null,

      // Hover/interaction
      hoveredLinkIndex: controller._hoveredLinkIndex || -1,
      totalLinks: controller.links?.length || 0,

      // Recording
      recordingActive: controller._recording?.active || false,
      recordingCC: controller._recording?.ccNumber || null,
      recordingSamples: controller._recording?.samples?.length || 0,

      // Groups and nodes
      totalNodes: controller.nodes?.length || 0,
      totalGroups: controller.groups?.length || 0,
      activeGroups: controller.groups?.filter(g => g.playStart != null).length || 0,

      // Press context
      pressNode: controller._pressCtx?.node?.label || null,
      pressCreateType: controller._pressCtx?.createType || null,

      // Guides
      guideV: controller._guideV,
      guideH: controller._guideH
    };
  }

  formatLines(info) {
    const lines = [];

    // Interaction states
    if (info.draggingNode) {
      lines.push(`DRAGGING NODE: ${info.draggingNodeName || 'unknown'}`);
    }
    if (info.draggingCable) {
      lines.push('DRAGGING CABLE: TRUE');
    }
    if (info.draggingTrigger) {
      lines.push(`DRAGGING TRIGGER: ${info.draggingTriggerType || 'unknown'}`);
    }

    // Deletion states
    if (info.deletionPending) {
      lines.push('DELETION PENDING: TRUE');
    }
    if (info.boxDeletionNode) {
      lines.push(`BOX DELETE: ${info.boxDeletionNode}`);
    }
    if (info.triggerDeletionPending) {
      lines.push('TRIGGER DELETE PENDING: TRUE');
    }
    if (info.triggerDeletionNode) {
      lines.push(`TRIGGER DELETE: ${info.triggerDeletionNode} (${info.triggerDeletionType})`);
    }

    // Recording
    if (info.recordingActive) {
      lines.push(`RECORDING: CC${info.recordingCC} (${info.recordingSamples} samples)`);
    }

    // Hover/selection
    if (info.hoveredLinkIndex >= 0) {
      lines.push(`HOVERED LINK: ${info.hoveredLinkIndex}/${info.totalLinks}`);
    }

    // Scene info
    lines.push(`NODES: ${info.totalNodes} | LINKS: ${info.totalLinks}`);
    if (info.totalGroups > 0) {
      lines.push(`GROUPS: ${info.totalGroups} (${info.activeGroups} active)`);
    }

    // Press context
    if (info.pressNode) {
      const createInfo = info.pressCreateType ? ` (create ${info.pressCreateType})` : '';
      lines.push(`PRESS: ${info.pressNode}${createInfo}`);
    }

    // Guides
    if (info.guideV !== null || info.guideH !== null) {
      const guides = [];
      if (info.guideV !== null) guides.push(`V:${info.guideV.toFixed(0)}`);
      if (info.guideH !== null) guides.push(`H:${info.guideH.toFixed(0)}`);
      lines.push(`GUIDES: ${guides.join(', ')}`);
    }

    // If nothing interesting is happening
    if (lines.length === 1) { // Only scene info line
      lines.push('STATE: IDLE');
    }

    return lines;
  }
}

export default DebugHUDView;
