/* Global configuration constants for the Midi Visualizer (MVC) */

// Node box dimensions and visuals
export const BOX_W = 200;
export const BOX_H = 80;

// Ports
export const PORT_R = 7;
export const PORT_LEFT = "left";
export const PORT_RIGHT = "right";
export const PORT_BOTTOM_TRIGGER = "bottomTrigger";
export const PORT_RIGHT_TRIGGER = "rightTrigger";
export const PORT_TOP_TRIGGER = "topTrigger";
export const PORT_LEFT_TRIGGER = "leftTrigger";
export const PORT_SIGNAL = "signal"; // diamond ports

// Hit thresholds
export const CABLE_HIT_THRESH = 6;
export const TRIGGER_HIT_THRESH = 8;
export const TRIGGER_HIT_RIGHTCLICK = 16;
export const DELETE_ICON_R = 10;

// Gestures
export const CLICK_DRAG_THRESHOLD = 5;

// Playback - Duration-based system
export const PLAY_DURATION_MS = 2000;
export const BLINK_MS = 220;
export const BLINK_RING_EXTRA = 2.5;

// Default duration for synthetic nodes (matches original pixel-based speed)
export const DEFAULT_PLAYBACK_DURATION_MS = 1500; // 1.5 seconds - closer to original speed

// Graph play speed: constant pixel/sec (DEPRECATED - will be replaced by duration-based timing)
export const SPEED_PX_PER_SEC = (BOX_W - 16) / (PLAY_DURATION_MS / 1000);

// Recording overlay (reserved for later/refactor parity)
export const TRH = 27;
export const STACK_GAP = 6;
export const SIMUL_WIN_MS = 5;
export const NB_STACK_GAP = 12;

// Grouping & Docking (enhanced for Priority 2.1)
export const SNAP_PX = 8;
export const SNAP_NEAR_PX = 20;
export const GUIDE_ALPHA = 190;

// Port visibility
export const PORT_VIS_PX = 20; // show if mouse within N px of node rect, or connected

// Helpers
export const KEY_SHIFT = 16;
export const KEY_ALT = 18;

// Misc
export const FONT_FAMILY = "sans-serif";
