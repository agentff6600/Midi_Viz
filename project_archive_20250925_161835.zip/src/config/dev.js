export const DEV = {
  // Master debug switches
  DEBUG: true,            // Enable debug logging
  HUD: true,              // Enable on-canvas debug HUD

  // Logging level: 'debug' | 'info' | 'warn' | 'error' | 'none'
  LOG_LEVEL: 'debug'
};

// Runtime override example:
// window.__DEV = { ...DEV, LOG_LEVEL: 'info', HUD: false };
