import AppController from './controllers/AppController.js';

// Bootstrap: expose p5 lifecycle to window so global-mode p5 (loaded in index.html) can call into our controller.
const app = new AppController();

window.setup = () => app.setup();
window.draw = () => app.draw();
window.windowResized = () => app.windowResized();

// Handle mouse events with right-click detection
window.mousePressed = () => {
  // Debug mouse button detection
  console.log('mousePressed - mouseButton:', window.mouseButton, 'LEFT:', window.LEFT, 'RIGHT:', window.RIGHT);
  
  // p5.js mouseButton is an object with properties: {left: bool, right: bool, center: bool}
  let button = 'left';
  if (typeof window.mouseButton !== 'undefined') {
    if (window.mouseButton.right) {
      button = 'right';
      console.log('Detected right-click!');
    } else if (window.mouseButton.center) {
      button = 'center';
    }
  }
  
  console.log('Calling app.mousePressed(' + button + ')');
  app.mousePressed(button);
  console.log('After app.mousePressed call');
  
  // Prevent context menu only after processing
  if (button === 'right') {
    return false;
  }
  return false; // Prevent default browser behavior
};

window.mouseDragged = () => app.mouseDragged();
window.mouseReleased = () => app.mouseReleased();

// Wire up keyboard events (Priority 3.2)
window.keyPressed = () => app.keyPressed();

// Prevent context menu on canvas
window.contextMenu = (event) => {
  event.preventDefault();
  return false;
};

// Optional: expose for debugging
window.__app = app;
