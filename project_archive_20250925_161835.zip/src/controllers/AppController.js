import { FONT_FAMILY, PORT_TOP_TRIGGER, PORT_BOTTOM_TRIGGER, PORT_LEFT_TRIGGER, PORT_RIGHT_TRIGGER, PORT_VIS_PX, CABLE_HIT_THRESH, DELETE_ICON_R, SNAP_PX, SNAP_NEAR_PX, GUIDE_ALPHA, KEY_ALT } from '../config/constants.js';
import { pointRectDistance, dist2, computeDockSnap } from '../utils/geometry.js';
import { log } from '../utils/logger.js';
import { DEV } from '../config/dev.js';
import MidiModel from '../models/MidiModel.js';
import NodeBox from '../models/NodeBox.js';
import Link from '../models/Link.js';
import NodeView from '../views/NodeView.js';
import ConnectionView from '../views/ConnectionView.js';
import DebugHUDView from '../views/DebugHUDView.js';

class AppController {
  constructor() {
    // Models
    this.midi = new MidiModel();
    this.nodes = [];
    this.links = [];

    // Views
    this.nodeView = new NodeView();
    this.connView = new ConnectionView();
    this.debugHUD = new DebugHUDView();

    // Debug state (Phase 0 Guardrails)
    this.debug = { hud: false };

    // Interaction state
    this._draggingNode = { active: false, node: null, dx: 0, dy: 0 };
    this._draggingCable = { active: false, fromPort: null, toMouse: null };
    this._draggingTrigger = { active: false, node: null, triggerIndex: -1 };
    this._pressCtx = { node: null, x: 0, y: 0 };
    
    // Cable hover detection (Priority 1.2)
    this._hoveredLinkIndex = -1;
    
    // Docking guides (Priority 2.1A)
    this._guideV = null; // Vertical guide X position
    this._guideH = null; // Horizontal guide Y position
    
    // Node grouping system (Priority 2.1B)  
    this.groups = []; // [{members: Set, playStart: number, durationMs: number}]
    
    // Node deletion system (Priority 2.1C) - State machine like monolithic
    this._boxDeletion = { node: null }; // matches monolithic boxDeletionController._
    this._deletionPending = false; // Track if deletion should happen on release
    
    // Trigger deletion system (Priority 2.2B)
    this._triggerDeletion = { node: null, triggerType: null, triggerIndex: -1 };
    this._triggerDeletionPending = false;
    
    // Recording system (Priority 3.2)
    this._recording = {
      active: false,
      startTime: 0,
      ccNumber: 1,
      samples: [],
      lastValue: -1
    };
  }

  // p5 lifecycle
  setup() {
    // p5 global (from index.html) is available
    createCanvas(windowWidth, windowHeight);
    pixelDensity(Math.min(2, window.devicePixelRatio || 1));
    textFont(FONT_FAMILY);
    noSmooth();

    // Remove loader overlay
    const loader = document.getElementById('app-loader');
    if (loader) loader.remove();

    // MIDI
    this.midi.init();

    // Set up MIDI recording callback (Priority 3.2)
    this.midi.onCCReceived = (ch, cc, val, timestamp, sourceInfo) => {
      this.handleMIDIInput(ch, cc, val, timestamp, sourceInfo);
    };

    // Seed example nodes (like original sketch)
    this.nodes.push(new NodeBox(120, 120, 'CC 10', NodeBox.makeSine(200)));
    this.nodes.push(new NodeBox(420, 260, 'CC 74', NodeBox.makeSaw(200)));
    this.nodes.push(new NodeBox(220, 420, 'CC 1', NodeBox.makeRandomSmooth(200)));

    // Set up trigger propagation for all nodes
    for (const node of this.nodes) {
      node.onTriggerFired = (sourcePort, triggerU) => this.handleTriggerPropagation(sourcePort, triggerU);
    }

    log.info('AppController', 'Setup complete - Phase 0 Guardrails active');
  }

  draw() {
    background(0);

    // Update cable hover detection
    this.updateCableHover();

    // Update models (playback, etc.) then draw
    for (const n of this.nodes) {
      n.updateAndMaybeSend(this.midi);
    }

    // Connections first (under nodes) - with hover state
    for (let i = 0; i < this.links.length; i++) {
      const l = this.links[i];
      const isHovered = (i === this._hoveredLinkIndex);
      this.connView.draw(l, isHovered);
    }

    // Dragging cable preview with target detection
    if (this._draggingCable.active && this._draggingCable.fromPort) {
      const targetPort = this.findPortUnderMouse(mouseX, mouseY);
      this.connView.drawPreview(
        this._draggingCable.fromPort, 
        this._draggingCable.toMouse || createVector(mouseX, mouseY),
        targetPort
      );
    }

    // Nodes (on top) - pass controller for port visibility
    for (const n of this.nodes) {
      this.nodeView.draw(n, this);
    }

    // Draw docking guides (Priority 2.1A)
    if (this._guideV !== null) {
      stroke(80, 160, 255, GUIDE_ALPHA);
      strokeWeight(1);
      line(this._guideV, 0, this._guideV, height);
    }
    if (this._guideH !== null) {
      stroke(80, 160, 255, GUIDE_ALPHA);
      strokeWeight(1);
      line(0, this._guideH, width, this._guideH);
    }

    // Draw group playheads (Priority 2.1B) - blue vertical lines
    this.updateAndDrawGroupPlayheads();
    
    // Draw node deletion overlay (Priority 2.1C)
    this.boxDeletionController('draw');
    
    // Draw trigger deletion overlay (Priority 2.2B)
    this.triggerDeletionController('draw');
    
    // Draw recording overlay (Priority 3.2)
    this.drawRecordingOverlay();

    // Debug HUD (Phase 0 Guardrails) - draw last for visibility
    if (this.debug.hud && DEV.HUD) {
      this.debugHUD.draw(window, this);
    }
  }

  windowResized() {
    resizeCanvas(windowWidth, windowHeight);
  }

  // Keyboard event handler (Phase 0 Guardrails + Priority 3.2)
  keyPressed() {
    log.debug('KeyPress', `Key pressed: ${key}`);
    
    // Debug HUD toggle (Phase 0)
    if (key === 'd' || key === 'D') {
      this.debug.hud = !this.debug.hud;
      log.info('DebugHUD', `Debug HUD ${this.debug.hud ? 'enabled' : 'disabled'}`);
      return;
    }
    
    // Recording toggle (Priority 3.2)
    if (key === 'r' || key === 'R') {
      if (this._recording.active) {
        this.stopRecording();
      } else {
        this.startRecording();
      }
      return;
    }
  }

  // Mouse events with comprehensive logging
  mousePressed(button = 'left') {
    log.debug('MousePress', `mousePressed(${button}) at (${mouseX}, ${mouseY})`);
    
    // Right-click handling
    if (button === 'right') {
      const vTrigger = this.findVTriggerUnderMouse(mouseX, mouseY);
      if (vTrigger) {
        this._triggerDeletion.node = vTrigger.node;
        this._triggerDeletion.triggerType = 'v';
        this._triggerDeletion.triggerIndex = vTrigger.triggerIndex;
        log.debug('TriggerDeletion', `Right-clicked VTrigger on ${vTrigger.node.label}`);
        return;
      }
      
      const hTrigger = this.findHTriggerUnderMouse(mouseX, mouseY);
      if (hTrigger) {
        this._triggerDeletion.node = hTrigger.node;
        this._triggerDeletion.triggerType = 'h';
        this._triggerDeletion.triggerIndex = hTrigger.triggerIndex;
        log.debug('TriggerDeletion', `Right-clicked HTrigger on ${hTrigger.node.label}`);
        return;
      }
      
      const nodeUnder = this.topmostNodeUnder(mouseX, mouseY);
      if (nodeUnder) {
        this._boxDeletion.node = nodeUnder;
        log.debug('BoxDeletion', `Right-clicked ${nodeUnder.label}`);
        return;
      }
      
      this._boxDeletion.node = null;
      this._triggerDeletion.node = null;
      return;
    }

    // Left-click handling - check deletion first
    if (this.boxDeletionController('press')) {
      log.debug('BoxDeletion', 'Clicked delete icon');
      this._deletionPending = true;
      return;
    }
    
    if (this.triggerDeletionController('press')) {
      log.debug('TriggerDeletion', 'Clicked trigger delete icon');
      this._triggerDeletionPending = true;
      return;
    }

    this._boxDeletion.node = null;
    this._triggerDeletion.node = null;

    if (this.isOverCableDeleteIcon()) {
      this.links.splice(this._hoveredLinkIndex, 1);
      this._hoveredLinkIndex = -1;
      return;
    }

    const port = this.findPortUnderMouse(mouseX, mouseY);
    if (port && port.role === 'out') {
      this.bringNodeToFront(port.node);
      this._draggingCable.active = true;
      this._draggingCable.fromPort = port;
      this._draggingCable.toMouse = createVector(mouseX, mouseY);
      this._pressCtx.node = null;
      return;
    }

    const vTrigger = this.findVTriggerUnderMouse(mouseX, mouseY);
    if (vTrigger) {
      this.bringNodeToFront(vTrigger.node);
      this._draggingTrigger.active = true;
      this._draggingTrigger.node = vTrigger.node;
      this._draggingTrigger.triggerIndex = vTrigger.triggerIndex;
      this._draggingTrigger.triggerType = 'v';
      this._pressCtx.node = null;
      return;
    }

    const hTrigger = this.findHTriggerUnderMouse(mouseX, mouseY);
    if (hTrigger) {
      this.bringNodeToFront(hTrigger.node);
      this._draggingTrigger.active = true;
      this._draggingTrigger.node = hTrigger.node;
      this._draggingTrigger.triggerIndex = hTrigger.triggerIndex;
      this._draggingTrigger.triggerType = 'h';
      this._pressCtx.node = null;
      return;
    }

    const createVNode = this.findVTriggerCreateArea(mouseX, mouseY);
    if (createVNode) {
      this.bringNodeToFront(createVNode);
      this._pressCtx.node = createVNode;
      this._pressCtx.x = mouseX;
      this._pressCtx.y = mouseY;
      this._pressCtx.isCreateArea = true;
      this._pressCtx.createType = 'v';
      return;
    }

    const createHNode = this.findHTriggerCreateArea(mouseX, mouseY);
    if (createHNode) {
      this.bringNodeToFront(createHNode);
      this._pressCtx.node = createHNode;
      this._pressCtx.x = mouseX;
      this._pressCtx.y = mouseY;
      this._pressCtx.isCreateArea = true;
      this._pressCtx.createType = 'h';
      return;
    }

    const nUnder = this.topmostNodeUnder(mouseX, mouseY);
    if (nUnder) {
      this.bringNodeToFront(nUnder);
      this._pressCtx.node = nUnder;
      this._pressCtx.x = mouseX;
      this._pressCtx.y = mouseY;
      this._pressCtx.isCreateArea = false;

      this._draggingNode.active = true;
      this._draggingNode.node = nUnder;
      this._draggingNode.dx = mouseX - nUnder.x;
      this._draggingNode.dy = mouseY - nUnder.y;
      return;
    }

    this._pressCtx.node = null;
  }

  mouseDragged() {
    if (this._draggingCable.active) {
      if (!this._draggingCable.toMouse) this._draggingCable.toMouse = createVector(mouseX, mouseY);
      this._draggingCable.toMouse.set(mouseX, mouseY);
      return;
    }
    if (this._draggingTrigger.active) {
      const n = this._draggingTrigger.node;
      if (this._draggingTrigger.triggerType === 'v') {
        const vt = n.vTriggers[this._draggingTrigger.triggerIndex];
        if (vt) vt.setUFromMouseX(mouseX);
      } else if (this._draggingTrigger.triggerType === 'h') {
        const ht = n.hTriggers[this._draggingTrigger.triggerIndex];
        if (ht) ht.setVFromMouseY(mouseY);
      }
      return;
    }
    if (this._draggingNode.active && this._draggingNode.node) {
      const n = this._draggingNode.node;
      const proposedX = mouseX - this._draggingNode.dx;
      const proposedY = mouseY - this._draggingNode.dy;
      const snapResult = computeDockSnap(n, proposedX, proposedY, this.nodes, SNAP_PX, SNAP_NEAR_PX);
      const deltaX = snapResult.x - n.x;
      const deltaY = snapResult.y - n.y;
      
      const group = this.findGroupContaining(n);
      if (group && group.members.size > 1) {
        for (const groupNode of group.members) {
          groupNode.x += deltaX;
          groupNode.y += deltaY;
        }
        log.debug('GroupDrag', `Moving group of ${group.members.size} nodes`);
      } else {
        n.x = snapResult.x;
        n.y = snapResult.y;
      }
      
      this._guideV = snapResult.guideV;
      this._guideH = snapResult.guideH;
    }
  }

  mouseReleased() {
    log.debug('MouseRelease', `mouseReleased() at (${mouseX}, ${mouseY})`);
    
    if (this._deletionPending) {
      if (this.boxDeletionController('release')) {
        log.info('BoxDeletion', 'Released - node deleted');
        this._deletionPending = false;
        return;
      }
      this._deletionPending = false;
    }
    
    if (this._triggerDeletionPending) {
      if (this.triggerDeletionController('release')) {
        log.info('TriggerDeletion', 'Released - trigger deleted');
        this._triggerDeletionPending = false;
        return;
      }
      this._triggerDeletionPending = false;
    }

    if (this._draggingCable.active && this._draggingCable.fromPort) {
      const from = this._draggingCable.fromPort;
      const target = this.findPortUnderMouse(mouseX, mouseY);
      if (target && target !== from) {
        const normalConnection = (from.role === 'out' && target.role === 'in');
        if (normalConnection) {
          this.links.push(new Link(from, target));
        }
      }
    }
    this._draggingCable = { active: false, fromPort: null, toMouse: null };

    if (this._draggingTrigger.active) {
      this._draggingTrigger = { active: false, node: null, triggerIndex: -1 };
      return;
    }

    if (this._draggingNode.active) {
      const n = this._draggingNode.node;
      const moved = n ? Math.hypot(mouseX - this._pressCtx.x, mouseY - this._pressCtx.y) > 5 : false;
      
      log.debug('NodeDrag', `mouseReleased: node=${n?.label}, moved=${moved}`);

      let snappedTo = null;
      if (moved && (this._guideV !== null || this._guideH !== null)) {
        for (const otherNode of this.nodes) {
          if (otherNode !== n && this.shouldCreateGroup(n, otherNode)) {
            snappedTo = otherNode;
            break;
          }
        }
        
        if (snappedTo) {
          this.ensureGroupWith(n, snappedTo);
          log.info('Grouping', `Node ${n.label} snapped to ${snappedTo.label}`);
        }
      } else if (moved) {
        for (const otherNode of this.nodes) {
          if (otherNode !== n && this.shouldCreateGroup(n, otherNode)) {
            snappedTo = otherNode;
            this.ensureGroupWith(n, snappedTo);
            log.info('Grouping', `Node ${n.label} moved near ${snappedTo.label}`);
            break;
          }
        }
      }

      this._draggingNode = { active: false, node: null, dx: 0, dy: 0 };
      this._guideV = null;
      this._guideH = null;

      if (!moved && this._pressCtx.node) {
        const group = this.findGroupContaining(this._pressCtx.node);
        if (group) {
          this.startGroupFromStart(group);
        } else if (typeof this._pressCtx.node.startPlayback === 'function') {
          this._pressCtx.node.startPlayback();
        }
      }
    }

    if (this._pressCtx.node && this._pressCtx.isCreateArea) {
      const moved = Math.hypot(mouseX - this._pressCtx.x, mouseY - this._pressCtx.y) > 5;
      if (!moved) {
        if (this._pressCtx.createType === 'v') {
          this._pressCtx.node.addVTriggerAtMouse(mouseX);
        } else if (this._pressCtx.createType === 'h') {
          this._pressCtx.node.addHTriggerAtMouse(mouseY);
        }
      }
    }

    this._pressCtx.node = null;
    this._pressCtx.isCreateArea = false;
    this._pressCtx.createType = null;
  }

  // Recording System
  handleMIDIInput(ch, cc, val, timestamp, sourceInfo) {
    if (this._recording.active && cc === this._recording.ccNumber) {
      const relativeTime = timestamp - this._recording.startTime;
      this._recording.samples.push({ time: relativeTime, value: val });
      this._recording.lastValue = val;
      log.debug('Recording', `CC${cc}: ${val} at ${relativeTime.toFixed(1)}ms`);
    }
  }

  startRecording() {
    if (this._recording.active) return;
    const lastCC = this.midi.lastGlobalCC || 1;
    this._recording = { active: true, startTime: performance.now(), ccNumber: lastCC, samples: [], lastValue: -1 };
    log.info('Recording', `Started recording CC${this._recording.ccNumber}`);
  }

  stopRecording() {
    if (!this._recording.active) return;
    const duration = performance.now() - this._recording.startTime;
    const samples = [...this._recording.samples];
    this._recording.active = false;
    if (samples.length > 0) this.generateNodeFromRecording(this._recording.ccNumber, samples, duration);
    log.info('Recording', `Stopped recording - ${samples.length} samples`);
  }

  generateNodeFromRecording(ccNumber, samples, durationMs) {
    let nodeX = 100, nodeY = 100;
    for (let i = 0; i < 10; i++) {
      let overlapping = false;
      for (const node of this.nodes) {
        if (Math.hypot(nodeX - node.x, nodeY - node.y) < 150) {
          overlapping = true; break;
        }
      }
      if (!overlapping) break;
      nodeX += 50;
      if (nodeX > width - 200) { nodeX = 100; nodeY += 100; }
    }
    const waveformData = samples.map(s => s.value / 127);
    const nodeWidth = Math.max(150, Math.min(400, durationMs / 10));
    const newNode = new NodeBox(nodeX, nodeY, `CC ${ccNumber} (Rec)`, waveformData, nodeWidth);
    newNode.cc = ccNumber;
    newNode.durationMs = durationMs;
    this.addNode(newNode);
    log.info('Recording', `Generated recorded node at (${nodeX}, ${nodeY})`);
  }

  drawRecordingOverlay() {
    if (!this._recording.active) return;
    const size = 60, margin = 20;
    const pulseAlpha = 100 + 155 * (0.5 + 0.5 * Math.sin(millis() * 0.01));
    noStroke(); fill(255, 0, 0, pulseAlpha);
    circle(margin + size/2, margin + size/2, size);
    fill(255); textAlign(CENTER, CENTER); textSize(12);
    text('REC', margin + size/2, margin + size/2);
    const duration = (performance.now() - this._recording.startTime) / 1000;
    textAlign(LEFT, TOP); textSize(11); fill(255, 200);
    text(`CC${this._recording.ccNumber}`, margin, margin + size + 5);
    text(`${duration.toFixed(1)}s`, margin, margin + size + 20);
    text(`${this._recording.samples.length} samples`, margin, margin + size + 35);
  }

  // Trigger propagation
  handleTriggerPropagation(sourcePort, triggerValue) {
    for (const link of this.links) {
      if (link.a === sourcePort) {
        const targetPort = link.b;
        const targetNode = targetPort.node;
        
        if (targetPort.kind === PORT_TOP_TRIGGER) {
          for (const vt of targetNode.vTriggers) {
            if (vt.portIn === targetPort) {
              targetNode.startPlaybackFromU(vt.u);
              log.info('TriggerProp', `Started ${targetNode.label} from VTrigger`);
              break;
            }
          }
        }
        else if (targetPort.kind === PORT_LEFT_TRIGGER || targetPort.kind === PORT_RIGHT_TRIGGER) {
          targetNode.startPlayback();
          log.info('TriggerProp', `Started ${targetNode.label} from HTrigger`);
        }
        else if (targetPort.role === 'in') {
          targetNode.startPlayback();
          log.info('TriggerProp', `Started ${targetNode.label} from beginning`);
        }
      }
    }
  }

  // Helper methods
  bringNodeToFront(node) {
    const i = this.nodes.indexOf(node);
    if (i >= 0) { this.nodes.splice(i, 1); this.nodes.push(node); }
  }

  topmostNodeUnder(mx, my) {
    for (let i = this.nodes.length - 1; i >= 0; --i) {
      const n = this.nodes[i];
      if (n.bodyHits(mx, my)) return n;
    }
    return null;
  }

  findPortUnderMouse(mx, my) {
    for (let i = this.nodes.length - 1; i >= 0; --i) {
      const n = this.nodes[i];
      const allPorts = n.getAllPorts();
      for (const port of allPorts) {
        if (port && port.hits(mx, my)) return port;
      }
    }
    return null;
  }

  findVTriggerUnderMouse(mx, my) {
    for (let ni = this.nodes.length - 1; ni >= 0; --ni) {
      const n = this.nodes[ni];
      for (let ti = 0; ti < n.vTriggers.length; ti++) {
        const vt = n.vTriggers[ti];
        const x = vt.getX();
        if (Math.abs(mx - x) <= 4 && my >= n.y && my <= n.y + n.h) {
          return { node: n, nodeIndex: ni, triggerIndex: ti, trigger: vt };
        }
      }
    }
    return null;
  }

  findHTriggerUnderMouse(mx, my) {
    for (let ni = this.nodes.length - 1; ni >= 0; --ni) {
      const n = this.nodes[ni];
      for (let ti = 0; ti < n.hTriggers.length; ti++) {
        const ht = n.hTriggers[ti];
        const y = ht.getY();
        if (Math.abs(my - y) <= 4 && mx >= n.x && mx <= n.x + n.w) {
          return { node: n, nodeIndex: ni, triggerIndex: ti, trigger: ht };
        }
      }
    }
    return null;
  }

  findVTriggerCreateArea(mx, my) {
    for (let i = this.nodes.length - 1; i >= 0; --i) {
      const n = this.nodes[i];
      const createRect = n.getTopCreateRect();
      if (createRect.h > 0 && 
          mx >= createRect.x && mx <= createRect.x + createRect.w &&
          my >= createRect.y && my <= createRect.y + createRect.h) {
        return n;
      }
    }
    return null;
  }

  findHTriggerCreateArea(mx, my) {
    for (let i = this.nodes.length - 1; i >= 0; --i) {
      const n = this.nodes[i];
      const createRect = n.getRightCreateRect();
      if (createRect.w > 0 && 
          mx >= createRect.x && mx <= createRect.x + createRect.w &&
          my >= createRect.y && my <= createRect.y + createRect.h) {
        return n;
      }
    }
    return null;
  }

  // Deletion controllers
  boxDeletionController(op) {
    if (op === 'press') {
      log.debug('BoxDeletion', `Checking deletion press: ${this._boxDeletion.node?.label}`);
      if (this._boxDeletion.node) {
        const n = this._boxDeletion.node;
        const iconX = n.x + n.w / 2;
        const iconY = n.y + n.h / 2;
        if (dist2(mouseX, mouseY, iconX, iconY) <= (DELETE_ICON_R * DELETE_ICON_R)) {
          log.debug('BoxDeletion', `Delete icon clicked for ${n.label}`);
          return true;
        }
      }
      return false;
    }
    
    if (op === 'release') {
      if (this._boxDeletion.node) {
        log.info('BoxDeletion', `Deleting node: ${this._boxDeletion.node.label}`);
        this.deleteNode(this._boxDeletion.node);
        this._boxDeletion.node = null;
        return true;
      }
      return false;
    }
    
    if (op === 'draw') {
      if (this._boxDeletion.node) {
        const node = this._boxDeletion.node;
        noStroke(); fill(0, 128); rect(node.x, node.y, node.w, node.h);
        const iconX = node.x + node.w / 2;
        const iconY = node.y + node.h / 2;
        stroke(255); strokeWeight(2); fill(0); circle(iconX, iconY, DELETE_ICON_R * 2);
        const r = DELETE_ICON_R * 0.6;
        line(iconX - r, iconY - r, iconX + r, iconY + r);
        line(iconX - r, iconY + r, iconX + r, iconY - r);
      }
    }
  }

  triggerDeletionController(op) {
    if (op === 'press') {
      if (this._triggerDeletion.node && this._triggerDeletion.triggerType) {
        const node = this._triggerDeletion.node;
        let iconX, iconY;
        if (this._triggerDeletion.triggerType === 'v') {
          const vt = node.vTriggers[this._triggerDeletion.triggerIndex];
          if (vt) { iconX = vt.getX(); iconY = node.y + node.h / 2; }
        } else if (this._triggerDeletion.triggerType === 'h') {
          const ht = node.hTriggers[this._triggerDeletion.triggerIndex];
          if (ht) { iconX = node.x + node.w / 2; iconY = ht.get
